#include <stdio.h>

void getSHA256_Digest(char* digest, char* buffer, ssize_t len);



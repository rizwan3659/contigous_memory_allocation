#include "main.h"

int main(int argc, char *argv[]) {
	fprintf(stdout, "Finish the implementation by semester's end :)\n");
}

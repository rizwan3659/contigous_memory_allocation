#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include "disk.h"

#define MAGIC_NUMBER 0xf0f03410
#define INODE_START 1
#define INODE_RATIO 0.1

struct SuperBlock {
    unsigned int start;
    unsigned int total_blocks;
    unsigned int inode_blocks;
    unsigned int inodes_used;
};

struct INode {
    unsigned int valid;
    unsigned int size;
    char SHA256[32];
    unsigned int direct_blockref[5];
    unsigned int indirect_blockref;
};

struct INodeBlock {
   struct INode inode[BLOCK_SIZE / sizeof(struct INode)];
};

struct ReferenceBlock {
    unsigned int references[BLOCK_SIZE / sizeof(unsigned int)];
};

struct DataBlock {
    char data[BLOCK_SIZE];
};

struct SuperBlock FirstBlock;


size_t create();
ssize_t read(size_t inumber, char *data, size_t length, size_t offset);
bool remove_inode(size_t inumber);
ssize_t stat_inode(size_t inumber);
char*  write(size_t inumber, char *data, size_t length, size_t offset);
unsigned short get_inode_count(FILE* emu_disk, size_t size);

int FS_create(FILE* emu_disk);
int FS_write_inode(FILE* emu_disk, size_t inode_number, struct INode inode) ;
struct INodeBlock FS_read_inode_block(FILE* emu_disk, size_t inode_block);


// Helpers
size_t FS_get_inode_block_count(size_t size);
size_t FS_get_data_block_count(size_t size);
void FS_printp_inode(struct INode inode);

#include "disk.h"

FILE* emu_disk_open(char *path, size_t nblocks) {
    FILE* diskfile = NULL;
    if( (diskfile = fopen(path, "r") ) == NULL ) {
        fprintf(stderr, "File '%s' does not exist, creating with %lu blocks.\n", path, nblocks);
        // file does not exist, create        
        diskfile = fopen(path, "w+"); // reopen to be able to r/w
        fseek(diskfile, BLOCK_SIZE * nblocks - 1, SEEK_SET); // go to the last byte we need, minus one
        fputc('\0', diskfile); // place empty string null termiantor as last byte
        fflush(diskfile); // flush to make sure it's there
    }
    else {
        size_t exist_blocks = emu_disk_size(diskfile);
        fprintf(stderr, "File %s already exists with %lu blocks, using it instead.\n", path, exist_blocks);
        diskfile = freopen(path, "r+", diskfile);
    }
    return diskfile;
}

size_t emu_disk_size(FILE* diskfile) { 
    fseek(diskfile, 0, SEEK_END);
    size_t bytes = ftell(diskfile);
    if (bytes % BLOCK_SIZE != 0) {
        fprintf(stderr, "Error: File does not end on block boundary: %lu byte(s) left at the end!\n", bytes % BLOCK_SIZE);
        exit(1);
    }
    else 
        return bytes / BLOCK_SIZE;
}


void emu_disk_read(FILE* diskfile, int blocknum, char *data) {
    fseek(diskfile, BLOCK_SIZE * blocknum, SEEK_SET);
    fread(data, BLOCK_SIZE, 1, diskfile);
}


void emu_disk_write(FILE* diskfile, int blocknum, char *data) {
    if (fseek(diskfile, BLOCK_SIZE * blocknum, SEEK_SET) != 0)
        perror("Could not get to disk position!");
    if  (fwrite(data, BLOCK_SIZE, 1, diskfile) != 1)
        perror("Could not write block to disk!");
}

void emu_disk_close(FILE* diskfile) {
    fclose(diskfile);
}
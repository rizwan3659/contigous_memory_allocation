#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

int option = 1;
int listenfd = 0;	// Listening socket descriptor
int connfd = 0;	 // Connection socket descriptor
struct sockaddr_in serv_addr; // Address family for server
struct sockaddr_in cli_addr; // Address family for client

int FS_server_get_client_sockfd(int port);
void FS_server_client_handler(int sockfd_client);

#include "server.h"

int FS_server_get_client_sockfd(int port) {
    // Socket settings 
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(port);

    /* Get and set options on sockets */
    // Allow immediate reuse of the port and address
    setsockopt(listenfd, SOL_SOCKET, (SO_REUSEPORT | SO_REUSEADDR), (char*)&option, sizeof(option)); 

    /* Bind the port to the listening socket */
    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    /* Listen for connections on the listening socket */
    listen(listenfd, 10);

    /* Accept an incming client connection request */ 
    socklen_t clilen = sizeof(cli_addr);
    return accept(listenfd, (struct sockaddr*)&cli_addr, &clilen); // move the connection to a new descriptor

    /* REST: use connfd for everything, which frees up the listening descriptor for next connection request
    * NOTE: the connfd's port number on the server side is different from the listenfd's!
    */
}


void FS_server_client_handler(int sockfd_client) {
    // To be able to use select() to indicate data is there
    fd_set read_sd; // cretae a new set
    FD_ZERO(&read_sd); // empty the set
    FD_SET(sockfd_client, &read_sd); // add the client to the set

    while (1) {
        fd_set rsd = read_sd;
        int active_fdcount = select(sockfd_client+1 , &rsd, 0, 0, 0);
        if (active_fdcount > 0) { 
            char command[3] = {0};
            int bytes_read = recv(sockfd_client, command, sizeof(command), 0);
            if (bytes_read == 3) {
                if (strcmp(command, "CRE") == 0){
                    printf("CRE\n");
                    u_short size;
                    if( recv(sockfd_client, &size, sizeof(size), 0) == 2) {
                         printf("Creating new file, size %d blocks.\n", size);
                         // TBD
                    }
                    else {
                        printf("Wrong size.\n");
                        //break;
                    }
                }
                else if (strcmp(command, "DEL") == 0){
                    printf("DEL\n");
                }
                else if (strcmp(command, "DIR") == 0){
                    printf("DIR\n");
                }
                else if (strcmp(command, "GET") == 0){
                    printf("GET\n");
                }
                else if (strcmp(command, "MOD") == 0){
                    printf("MOD\n");
                }
                else if (strcmp(command, "PUT") == 0){
                    printf("PUT\n");
                }                           
            }
            else if (bytes_read == 0) {
                printf("Client disconnect.\n");
                break;
            }
            else {

            }
        }
        else if (active_fdcount < 0) {
            printf("NOTHING HERE.\n"); 
            break;
        }
    }
    close(sockfd_client);
}


